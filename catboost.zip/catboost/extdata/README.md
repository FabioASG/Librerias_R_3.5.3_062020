This data is a subset of the Adult Data Set from http://archive.ics.uci.edu/ml/datasets/adult
