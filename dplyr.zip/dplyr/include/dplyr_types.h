#include <dplyr/main.h>
#include <tools/Quosure.h>
#include <tools/BoolResult.h>
#include <dplyr/data/GroupedDataFrame.h>
#include <dplyr/data/DataMask.h>

// avoid inclusion of package header file
#define dplyr_dplyr_H
